export const colors = {
  primaryAccent: '#2a73fa',

  deletion: '#ff6969',
  errorParagraph: '#ff6969',

  swiper: {
    thumbBorder: '#4183ff',
    border: '#dbdbdb',
    background: 'rgba(255, 255, 255, 0.9)'
  }
};

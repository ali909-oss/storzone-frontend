import styled from 'styled-components/native';

export const CrewSelectsWrapper = styled.View`
  margin-top: 50px;
  display: flex;
  flex-direction: column;
`;

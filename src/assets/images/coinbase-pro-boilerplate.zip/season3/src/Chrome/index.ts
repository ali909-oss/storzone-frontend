import { tabs } from "./Tab";

export { default } from "./Chrome";

export const assets = tabs.map(tab => tab.thumbnail);

import React from "react";
import { Dimensions, StyleSheet, View } from "react-native";

import data from "./data.json";
import Values from "./Values";
import Line from "./Line";
import Content from "./Content";
import Header from "./Header";
import { Candle } from "./Model";

const { width: size } = Dimensions.get("window");
const candles = data.slice(0, 20);
const caliber = size / candles.length;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "black"
  }
});

export default () => {
  return (
    <View style={styles.container}>
      <View>
        <Header />
        <Values {...{ caliber, candles }} />
      </View>
      <View style={{ height: size }} />
      <Content />
    </View>
  );
};
